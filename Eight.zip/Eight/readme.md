迟交原因：近期课业繁多，需要准备考试
一。基础作业：利用乌龟绘制“8”图案
在学习的过程中，我发现操作ros2是一个复杂而且逻辑性强的过程，因此首先让AI带着我，以python（我对py比较熟悉）为编程语言，通过实现乌龟作圆周运动来经历一遍ros2的操作过程。然后以此为基础，通过模仿该流程，最终完成本次基础作业，下面是我所总结的ros2操作过程
1.配置环境：下载ros2，并配置环境变量（如果没有配置环境变量，需要在colcon build 之后执行source install/setup.bash命令）
2.创建ros2_ws/src/turtle_circle文件作为功能包（在创建python功能包过程中，我发现好像不能直接在创建包的同时添加依赖，因此先通过os2 pkg create --build-type ament_python turtle_circle命令创建一个为添加依赖的python功能包，后续通过手动方法在package.xml中添加依赖）
3.新建参数文件夹config(存放.yaml参数文件)，和启动文件文件夹launch(启动节点等)
4.在package.xml中添加依赖（gedit package.xml），在<license>标签下方添加依赖（如<depend>turtlesim</depend>等）
5.编写参数文件：进入config文件夹，gedit circle_params.yaml命令进入编辑参数文件，参数包括线速度，角速度等
6.编写发布节点：进入到～/src/turtle_circle/turtle_circle文件夹中，启动gedit circle_pub.py文件，编写启动节点代码
7.编写订阅节点代码（同上）
8.修改setup.py文件（将节点以及相关文件夹写入）
9.编写launch启动文件
10.回到工作空间根目录（ros2_ws）进行colcon build命令编译
11.在加载了工作空间环境的情况下，启动程序ros2 launch turtle_circle start_turtle.launch.py
总体来讲，我是通过AI进行模仿学习的，所以在一些文件构成关系的理解上可能存在一定疏漏，后续仍需通过实际操作加深理解
二。进阶作业
进阶部分难度较高，目前暂未完成，后续会继续攻克。
