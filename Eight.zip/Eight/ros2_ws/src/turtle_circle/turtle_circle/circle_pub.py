import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class TurtleCirclePub(Node):
    def __init__(self):
        super().__init__("turtle_circle_pub")

        # 声明参数
        self.declare_parameter("linear_vel", 1.0)
        self.declare_parameter("angular_vel", 2.0)
        self.declare_parameter("pub_frequency", 10.0)
        self.declare_parameter("switch_time", 4.0)

        # 读取参数
        self.linear = self.get_parameter("linear_vel").get_parameter_value().double_value
        self.angular = self.get_parameter("angular_vel").get_parameter_value().double_value
        freq = self.get_parameter("pub_frequency").get_parameter_value().double_value
        self.switch_time = self.get_parameter("switch_time").get_parameter_value().double_value

        # 创建发布器
        self.pub = self.create_publisher(Twist, "/turtle1/cmd_vel", 10)
        # 发布定时器
        timer_period = 1.0 / freq
        self.timer = self.create_timer(timer_period, self.timer_callback)

        # 转向状态 + 切换定时器
        self.turn_left = True
        self.switch_timer = self.create_timer(self.switch_time, self.switch_dir)

        self.get_logger().info("发布节点启动，准备控制海龟走八字")

    # 切换左右转向
    def switch_dir(self):
        self.turn_left = not self.turn_left

    # 定时发布速度指令
    def timer_callback(self):
        twist_msg = Twist()
        twist_msg.linear.x = self.linear
        if self.turn_left:
            twist_msg.angular.z = self.angular
        else:
            twist_msg.angular.z = -self.angular
        self.pub.publish(twist_msg)

def main():
    rclpy.init()
    node = TurtleCirclePub()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()

