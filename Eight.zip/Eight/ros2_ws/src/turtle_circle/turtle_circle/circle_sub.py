import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class TurtleCircleSub(Node):
    def __init__(self):
        super().__init__("turtle_circle_sub")
        # 创建订阅器，话题、消息类型必须和发布端一致
        self.sub = self.create_subscription(
            Twist,
            "/turtle1/cmd_vel",
            self.sub_callback,
            10
        )
        self.get_logger().info("订阅节点启动，开始接收数据")

    # 收到数据自动执行此回调函数
    def sub_callback(self, msg):
        linear_x = msg.linear.x
        angular_z = msg.angular.z
        self.get_logger().info(f"收到数据 | 线速度:{linear_x:.2f} 角速度:{angular_z:.2f}")

def main():
    rclpy.init()
    node = TurtleCircleSub()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()

