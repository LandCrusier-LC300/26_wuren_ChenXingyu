from launch import LaunchDescription
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch.substitutions import PathJoinSubstitution

def generate_launch_description():
    # 加载yaml参数文件
    param_file = PathJoinSubstitution([
        FindPackageShare("turtle_circle"),
        "config",
        "circle_params.yaml"
    ])

    # 1. 海龟仿真节点
    turtle_sim = Node(
        package="turtlesim",
        executable="turtlesim_node",
        output="screen"
    )

    # 2. 发布节点 + 加载yaml参数
    pub_node = Node(
        package="turtle_circle",
        executable="circle_pub",
        name="turtle_circle_pub",
        parameters=[param_file],
        output="screen"
    )

    # 3. 订阅节点
    sub_node = Node(
        package="turtle_circle",
        executable="circle_sub",
        name="turtle_circle_sub",
        output="screen"
    )

    # 汇总所有节点
    return LaunchDescription([
        turtle_sim,
        pub_node,
        sub_node
    ])

